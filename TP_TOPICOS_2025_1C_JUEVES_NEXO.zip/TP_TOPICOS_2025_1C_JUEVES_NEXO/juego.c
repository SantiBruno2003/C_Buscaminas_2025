#include "dibujos.h"
#include "juego.h"


tDatosMatriz** crearMatriz(int dimension)
{
    tDatosMatriz **m;
    m=(tDatosMatriz**)malloc(sizeof(tDatosMatriz*)*dimension);
    if (!m)
    {
        printf("\n error al crear matriz");
        return NULL;
    }
    tDatosMatriz **puntFilaAct=m;
    tDatosMatriz **puntFilaFin=m+dimension;
    for (tDatosMatriz **i=puntFilaAct;i<puntFilaFin;i++)
    {
        *i=(tDatosMatriz*)malloc(sizeof(tDatosMatriz)*dimension);
        if (!*i)
        {
            destruirMatriz(m,i-puntFilaAct); // la matriz y el numero de filas que si llegaron a asignarse antes del fallo
            return NULL;
        }
    }
    return m;
}


void destruirMatriz(tDatosMatriz **m ,size_t filas)
{
    if (!m)
        return;
    tDatosMatriz **puntFilaAct=m;
    tDatosMatriz **puntFilaFin=m+filas;
    for (tDatosMatriz **i=puntFilaAct;i<puntFilaFin;i++)
    {
        free(*i);
    }
    free(m);
}

void inicializarMatrizEnCero(tDatosMatriz **m,int dimension)
{
    int i,j;
    for (i=0;i<dimension;i++)
    {
        for (j=0;j<dimension;j++)
        {
            (*(*(m+i)+j)).esBandera=0;
            (*(*(m+i)+j)).esBomba=0;
            (*(*(m+i)+j)).esRevelada=0;
            (*(*(m+i)+j)).minasAdyacentes=0;
        }
    }
}

int generarAleatorio (int min,int max)
{
    int aleatorio;
    aleatorio=(rand()%max)+min; //genero secuencias aleatorias de numeros
    return aleatorio;
}

void colocarBombasDespPrimerClick(tDatosMatriz **m,int dimension,int f,int c, int cantBombas)
{
    int cant=0,filaAleatoria,columAleatoria; //cant para la cant de bombas q va poniendo, fila y col aleatoria, para q elija aleatoria donde poner
    srand(time(NULL));
    //(*(*(m+f)+c)).esRevelada=1;//la del primer click, ya la ponemos en revelada
    while (cant<cantBombas)
    {
        filaAleatoria=generarAleatorio(0,dimension-1);  //5
        columAleatoria=generarAleatorio(0,dimension-1); //6
        if(filaAleatoria==f && columAleatoria==c)
        {
            continue;
        }
        if( ! (*(*(m+filaAleatoria)+columAleatoria)).esBomba) // si bomba==0
        {
            (*(*(m+filaAleatoria)+columAleatoria)).esBomba=-1;
            (*(*(m+filaAleatoria)+columAleatoria)).minasAdyacentes=-1; // se hace esto para el conteo de minas adyacentes mas adelante, si es bomba no mando a contar las adyacentes
            cant++;
        }
    }
}

void jugar (tDatosMatriz **m,int dimension,int cantBombas, TTF_Font* fuente)
{
    SDL_Window* win = NULL;
    SDL_Renderer* ren = NULL;

    inicializarSDL(&win, &ren, dimension); // inicializamos la ventana de sdl
    bucleJuego(m, dimension, cantBombas, win, ren, fuente);// le mandamos a la funcion del juego la ventana ya creada

}


int cuentaMinasAdyacentes(tDatosMatriz **m,int dimension,int f,int c)
{
    int total=0,di,dj,ni,nj;
        for (di = -1; di <= 1; ++di)
        {
        for (dj = -1; dj <= 1; ++dj)
        {
            // salto la propia casilla
            if (di == 0 && dj == 0)
                continue;

            ni = f + di, nj = c + dj;

            // compruebo que (ni,nj) esté dentro de los límites
            if (ni >= 0 && ni < dimension && nj >= 0 && nj < dimension) {
                // llego a m[ni][nj] con punteros:

                if ( (*(*(m+ni)+nj)).esBomba==-1 )
                    total++;
            }
        }
    }

    return total;
}


void llenarMinasAdyacentes (tDatosMatriz **m,int dimension) // llena el campo de mnas adyacentes
{
    int i,j;
    for(i=0;i<dimension;i++)
    {
        for(j=0;j<dimension;j++)
        {
            if ((*(*(m+i)+j)).minasAdyacentes==-1) //si exste lugar tiene bomba, vuelve a empezar
                continue;
            else
            {
             (*(*(m+i)+j)).minasAdyacentes=cuentaMinasAdyacentes(m,dimension,i,j);
            }
        }
    }
}



tConfig leerConfig() //lee archivo configuracion
{
    tConfig conf;
    FILE *fp = fopen(NombreArch, "r");
    if (!fp)
    {
        fprintf(stderr, "Error al abrir archivo de configuracion\n");
        exit (-1);
    }

    char linea[128];

    while (fgets(linea, sizeof linea, fp)) {
        char *eq = strchr(linea, '='); //
        if (!eq)
            continue;

        *eq = '\0';
        char *key = linea;
        char *val = eq + 1;
        trim(key);
        trim(val);

        if (strcmp(key, "dimension") == 0)
            {
                int d = atoi(val);
                if (d < 8 || d > 32)
                    {
                        fprintf(stderr,"dimension debe estar entre 8 y 32\n");
                        fclose(fp);
                        exit (-2);
                    }
                conf.dimension = d;
            }
            else if (strcmp(key,"cantidad_minas") == 0) {
                int totalCas = conf.dimension*conf.dimension;
                size_t L = strlen(val);

                if (L > 0 && val[L-1] == '%')
                    {
                        val[L-1] = '\0';
                        int pct = atoi(val);
                        if (pct <= 0)
                        {
                            fprintf(stderr,"Porcentaje inválido de minas: %s%%\n", val);
                            fclose(fp);
                            exit (-3);
                        }
                        conf.cantMinas = totalCas / pct; // porcentaje pasado a numero
                    }
            else {
                int m = atoi(val);
                if (m < 0 || m > totalCas) {
                    fprintf(stderr,
                        "cantidad_minas inválida: %d\n", m);
                    fclose(fp);
                    exit (-4);
                }
                conf.cantMinas = m;
            }
        }
    }

    fclose(fp);
    return conf;
}


void trim(char* cadena)
{
    char* fin;
    while (isspace((unsigned char)*cadena))
        cadena++;

    if (*cadena == 0)
        return;

    fin = cadena + strlen(cadena) - 1;
    while (fin > cadena && isspace((unsigned char)*fin))
        fin--;

    *(fin+1)= '\0';
}


void renderizarCelda(SDL_Renderer* ren, TTF_Font* fuente, tDatosMatriz celda, int fila, int col)
{
    int x0 = col * CELL_SIZE;
    int y0 = PARTE_SUPERIOR + fila * CELL_SIZE;

    SDL_Rect cell = { x0, y0, CELL_SIZE, CELL_SIZE };

    // 2) Fondo de la celda:
    if (celda.esRevelada)
        {
        // si está revelada, fondo blanco
        SDL_SetRenderDrawColor(ren, 255, 255, 255, 255);
        }
        else
            {
                // si NO está revelada, fondo gris
                SDL_SetRenderDrawColor(ren, 180, 180, 180, 255);
            }
        SDL_RenderFillRect(ren, &cell);

        // 3) Si está revelada, dibujo bomba o número:
        if (celda.esRevelada)
            {
                if (celda.esBomba == -1)
                {
                    // Bomba
                    dibujarBomba(ren, fila, col);
                } else
                    {
                        // Número de minas adyacentes
                        mostrarNumero(ren, fuente, celda.minasAdyacentes, fila, col);
                    }
            }
            // 4) Si NO está revelada pero tiene bandera, la sobrepongo:
            else if (celda.esBandera)
            {
                dibujarBandera(ren, fila, col);
            }

    // 5) Borde de la celda (siempre)
    SDL_SetRenderDrawColor(ren, 50, 50, 200, 255);
    SDL_RenderDrawRect(ren, &cell);
}

void bucleJuego(tDatosMatriz** m, int dimension, int cantBombas, SDL_Window* win, SDL_Renderer* ren, TTF_Font*fuente)
{
    // 1) Inicializar TTF
    if (!fuente) {
        SDL_Log("No se pudo inicializar la fuente");
        return;
    }

    // 2) Variables de control
    bool primerclick     = true;
    bool corriendo       = true;
    bool cheatMinas      = false;
    bool cheatUsado      = false;
    Uint32 cheatInicio   = 0;
    Uint32 inicioPartida = SDL_GetTicks();

    int total        = dimension * dimension;
    int seguras      = total - cantBombas;
    int descubiertas = 0;
    int bandPuestas  = 0;
    SDL_Event ev;

    // 3) Bucle principal
    while (corriendo)
    {
        // 3.1) Procesar eventos
        while (SDL_PollEvent(&ev))
        {
            // a) Cerrar ventana
            if (ev.type == SDL_QUIT) {
                corriendo = false;
            }
            // b) Atajo Ctrl+S para activar cheat (una sola vez)
            else if (ev.type == SDL_KEYDOWN && ev.key.repeat == 0) {
                if (ev.key.keysym.sym == SDLK_s &&
                    (SDL_GetModState() & KMOD_CTRL) &&
                    !cheatUsado)
                {
                    cheatMinas  = true;
                    cheatUsado  = true;
                    cheatInicio = SDL_GetTicks();
                }
            }
            // c) Click de ratón
            else if (ev.type == SDL_MOUSEBUTTONDOWN)
            {
                // coordenadas dentro del tablero
                int mx = ev.button.x;
                int my = ev.button.y - PARTE_SUPERIOR;
                if (mx < 0 || my < 0 ||
                    mx >= dimension * CELL_SIZE ||
                    my >= dimension * CELL_SIZE)
                    continue;

                int f = my / CELL_SIZE;
                int c = mx / CELL_SIZE;
                // obtenemos puntero a la celda con aritmética:
                tDatosMatriz *cel = (*(m + f) + c);

                // --- Izquierdo ---
                if (ev.button.button == SDL_BUTTON_LEFT)
                {
                    // primer click
                    if (primerclick && !cel->esBandera)
                    {
                        primerclick = false;
                        registrarClick("IZQ", f+1, c+1);

                        colocarBombasDespPrimerClick(m, dimension, f, c, cantBombas);
                        llenarMinasAdyacentes(m, dimension);

                        int nuevas0 = expandirAdyacentes(m, dimension, f, c);
                        descubiertas += nuevas0;
                    }

                    // clicks posteriores
                    if (!cel->esRevelada && !cel->esBandera)
                        {
                            if (cel->esBomba == -1) // Si es una bomba
                            {
                                cel->esRevelada = 1;
                                registrarClick("BOMBA", f+1, c+1);
                                registrarFin("DERROTA");

                                revelarTodas(m, dimension, ren, fuente);
                                animarDerrota(ren, fuente);
                                corriendo = false;
                            }
                            else // Si no es una bomba
                            {
                                registrarClick("IZQ", f+1, c+1);
                                int nuevas = expandirAdyacentes(m, dimension, f, c);
                                descubiertas += nuevas;
                                if (descubiertas == seguras) // Si se han descubierto todas las celdas seguras
                                {
                                    registrarFin("VICTORIA");
                                    animarVictoria(ren, fuente);
                                    //juegoTerminado = true; // El juego ha terminado en victoria
                                    corriendo = false; // ¡AQUÍ ESTÁ EL CAMBIO CLAVE! Esto sale del bucle principal.
                                }
                            }
                        }
                }
                // --- Derecho: poner/quitar bandera ---
                else if (ev.button.button == SDL_BUTTON_RIGHT)
                {
                    if (!cel->esRevelada)
                        {
                            cel->esBandera = !cel->esBandera;
                            if (cel->esBandera)
                                bandPuestas += 1;
                            else
                                bandPuestas -= 1;
                            registrarClick("DER", f+1, c+1);
                        }
                }
            }
        }

        // 3.2) Auto-desactivar cheat tras 3 segundos
        if (cheatMinas && SDL_GetTicks()-cheatInicio>= CHEAT_DURATION_MS)
        {
            cheatMinas = false;
        }

        // 4) Renderizar todo
        SDL_SetRenderDrawColor(ren, 200, 200, 200, 255);
        SDL_RenderClear(ren);

        // a) HUD superior (minas restantes + cronómetro)
        parteSuperior(ren, fuente, cantBombas, bandPuestas, inicioPartida);

        // b) Tablero
        for (int i = 0; i < dimension; ++i)
        {
            for (int j = 0; j < dimension; ++j)
            {
                // puntero a la celda
                tDatosMatriz *cel = (*(m + i) + j);

                // dibujo base (fondo, número, bomba, bandera…)
                renderizarCelda(ren, fuente, *(*(m + i) + j), i, j);

                // overlay del cheat: resaltar bombas
                if (cheatMinas && cel->esBomba == -1)
                {
                    SDL_SetRenderDrawBlendMode(ren, SDL_BLENDMODE_BLEND);
                    SDL_SetRenderDrawColor(ren, 0, 0, 255, 128);
                    SDL_Rect cell = {
                        j * CELL_SIZE,
                        PARTE_SUPERIOR + i * CELL_SIZE,
                        CELL_SIZE,
                        CELL_SIZE
                    };
                    SDL_RenderFillRect(ren, &cell);
                }
            }
        }

        SDL_RenderPresent(ren);
    }

    // 5) Limpiar
    cerrarTTF(fuente);
}

int expandirAdyacentes (tDatosMatriz **m,int dimension,int f,int c) // funcion recursiva, se llama a si mismo con una nueva posicion para contar las vecinas
{
    int contador=0;
    if (f<0||f>= dimension ||c<0||c>=dimension)// limite
        return 0;
    if ((*(*(m+f)+c)).esRevelada || (*(*(m+f)+c)).esBandera)// si esta revelada o tiene bandera, no la cuento
        return 0;

    (*(*(m+f)+c)).esRevelada=1;
    contador++;
     if ((*(*(m+f)+c)).minasAdyacentes==0)// si no tiene minas a su alrededor, recorro las celdas vecinas
     {
         for (int di = -1; di <= 1; ++di)
         {
             for (int dj = -1; dj <= 1; ++dj)
             {
                 if (di == 0 && dj == 0)
                    continue;
                 contador+=expandirAdyacentes(m,dimension,f+di,c+dj);// recorro una celda vecina, y cuando este en esa vecina, la mando a la funcion de nuevo con esos datos
             }
         }
     }
return contador;
}

void revelarTodas(tDatosMatriz** m, int dimension, SDL_Renderer* ren, TTF_Font* fuente) // para cuando perdes
{
    // Fondo y limpieza
    SDL_SetRenderDrawColor(ren, 200, 200, 200, 255);
    SDL_RenderClear(ren);

    // Recorro toda la matriz
    for (int i = 0; i < dimension; ++i)
    {
        for (int j = 0; j < dimension; ++j)
        {
            // Marco como revelada
            m[i][j].esRevelada = 1;
            // Vuelvo a dibujarla (bomba o número)
            renderizarCelda(ren, fuente, m[i][j], i, j);
        }
    }

    // Borde final
    SDL_RenderPresent(ren);
}


int guardarConfig(char *archivo,int dimension,int bombas) // funcion q guarda en el archivo conf las dimensiones q uso
{
    FILE *f=fopen(archivo,"w");// lo abre con w que es modo escritura de texto
    if (!f)
    {
        printf("\nError abriendo archivo para escribirlo");
        return 0;
    }
    fprintf(f,"dimension = %d\n",dimension);
    fprintf(f,"cantidad_minas = %d\n",bombas);
    fclose(f);
    return 1;
}


void logTiempo(FILE *f) // para el conteo del tiempo en la parte superior
{
    time_t t=time(NULL); //obtiene el tiempo actual en segundos desde 1 de enero de 1970
    struct tm *tm=localtime(&t); //convierte esos segundos a la hora actuyak
    char cadena[20]; // para guardar la hora
    strftime(cadena, sizeof cadena, "%Y-%m-%d %H:%M:%S", tm); //guarda en cadena la fecha
    fprintf(f,"[%s] ",cadena); //guarda en el archivo la hora

}

void registrarClick (char *tipo,int f,int c) // en tipo va si es derecho o izq
{
    FILE *fc=fopen("movimientos.log","a");
    if (!fc)
    {
        printf("\n error al abrir arch");
        exit (1);
    }
    logTiempo(fc);
    fprintf(fc,"CLICK %s; fila=%d; col=%d\n",tipo,f,c);
    fclose (fc);

}

void registrarInicio (char *usuario,int dimensiones, int cantMinas)
{
    FILE *fc=fopen("movimientos.log","a");
    if (!fc)
    {
        printf("\n error al abrir arch");
        exit (1);
    }
    logTiempo(fc);
    fprintf(fc,"INICIO; usuario=%s; dimensiones=%dx%d; minas=%d\n",usuario,dimensiones,dimensiones,cantMinas);
    fclose (fc);
}

void registrarFin (char* resultado)
{
    FILE *fc=fopen("movimientos.log","a");
    if (!fc)
    {
        printf("\n error al abrir arch");
        exit (1);
    }
    logTiempo(fc);
    fprintf(fc,"FIN DE PARTIDA! %s\n",resultado);
    fclose(fc);
}
