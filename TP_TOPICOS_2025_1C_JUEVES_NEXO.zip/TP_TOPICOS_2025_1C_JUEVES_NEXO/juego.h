#ifndef JUEGO_H_INCLUDED
#define JUEGO_H_INCLUDED
#include "dibujos.h"

typedef struct
{
    int esRevelada; //0 si no esta, 1 si si
    int esBomba; // tiene -1
    int esBandera; //
    int minasAdyacentes; //con una funcion
}tDatosMatriz;

typedef struct
{
    int dimension;
    int cantMinas;
}tConfig;


void jugar (tDatosMatriz**, int, int, TTF_Font*);
void bucleJuego(tDatosMatriz**, int, int, SDL_Window*, SDL_Renderer*, TTF_Font*);
tDatosMatriz** crearMatriz(int);
void destruirMatriz(tDatosMatriz**,size_t);
void inicializarMatrizEnCero(tDatosMatriz**,int);
void colocarBombasDespPrimerClick(tDatosMatriz**,int,int,int,int);
int generarAleatorio (int,int);
int cuentaMinasAdyacentes(tDatosMatriz**,int,int,int);
void llenarMinasAdyacentes (tDatosMatriz**,int);
void crearArch();
tConfig leerConfig();
void trim (char*);
int expandirAdyacentes (tDatosMatriz **,int,int,int);
void revelarTodas(tDatosMatriz**, int, SDL_Renderer*, TTF_Font*);


int guardarConfig(char*,int,int);
void registrarClick(char*,int,int);
void registrarInicio(char*,int,int);
void registrarFin (char*);
void logTiempo(FILE*);




#endif // JUEGO_H_INCLUDED

