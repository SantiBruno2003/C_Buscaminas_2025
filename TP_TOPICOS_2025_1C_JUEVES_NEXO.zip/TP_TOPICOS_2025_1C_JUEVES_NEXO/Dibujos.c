#include "dibujos.h"

SDL_Color colores[] =
{
    {0, 0, 0, 255},       // N - Negro
    {255, 255, 255, 255}, // B - Blanco
    {255, 0, 0, 255}      // R - Rojo
};

void dibujar(SDL_Window *ventana, SDL_Renderer *renderer, const int dibujo[8][8], int cx, int cy)
{

    int pixelSize = CELL_SIZE / PIXELES_X_LADO;
    int offsetX = cx * CELL_SIZE + (CELL_SIZE - 8 * pixelSize) / 2;
    int offsetY = cy * CELL_SIZE + (CELL_SIZE - 8 * pixelSize) / 2;

    for (int y = 0; y < 8; y++)
    {
        for (int x = 0; x < 8; x++)
        {
            SDL_SetRenderDrawColor(renderer,
                colores[dibujo[y][x]].r,
                colores[dibujo[y][x]].g,
                colores[dibujo[y][x]].b,
                255 // transparencia fija
            );

            SDL_Rect pixel = {
                offsetX + x * pixelSize,
                offsetY + y * pixelSize,
                pixelSize,
                pixelSize
            };

            SDL_RenderFillRect(renderer, &pixel);
        }
    }
}

void inicializarSDL(SDL_Window** win, SDL_Renderer** ren, int dimension)
{
    SDL_Init(SDL_INIT_VIDEO);
   *win = SDL_CreateWindow(
        "Buscaminas.NEXO",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        dimension * CELL_SIZE,                  // ancho igual
       PARTE_SUPERIOR + dimension * CELL_SIZE, // altura + espacio para HUD
        0
    );
    *ren = SDL_CreateRenderer(*win, -1, SDL_RENDERER_ACCELERATED);
}

void limpiarSDL(SDL_Window* win, SDL_Renderer* ren)
{
    SDL_DestroyRenderer(ren);
    SDL_DestroyWindow(win);
    SDL_Quit();
}

void borrarPantalla(SDL_Window *ventana, SDL_Renderer *renderer)
{
    SDL_RenderClear(renderer);
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
    SDL_Rect pixel = {0, 0, 0, 0};
    SDL_RenderFillRect(renderer, &pixel);
    SDL_RenderPresent(renderer);
}


void parteSuperior(SDL_Renderer *ren, TTF_Font *fuente,int totalMinas,int BandPuestas,Uint32 Tiempo)
{
    int minasRestantes;
    minasRestantes=totalMinas-BandPuestas;
    //tiempo transcurrido
    Uint32 ahora= SDL_GetTicks();
    Uint32 diffMs= ahora-Tiempo;
    int segsTot = diffMs / 1000;
    int  minutos  = segsTot / 60;
           segsTot %= 60;

     // 3) Preparamos color y buffers
    SDL_Color color = { 0, 0, 0, 255 };
    char texto[32];
    SDL_Surface *surf;
    SDL_Texture *tex;
    SDL_Rect     dst;

    //dibujo de minas restantes (arriba a la izq)

    sprintf(texto, "Minas Restantes: %d", minasRestantes); //texto
    surf = TTF_RenderText_Solid(fuente, texto, color);
    tex = SDL_CreateTextureFromSurface(ren, surf);
    dst.x= 10;              // 10px desde el borde izquierdo
    dst.y= 10;              // 10px desde el borde superior
    dst.w= surf->w;
    dst.h= surf->h;
    SDL_FreeSurface(surf);
    SDL_RenderCopy(ren, tex, NULL, &dst);
    SDL_DestroyTexture(tex);

    // dibujo del cronometro (arriba a la derecha)
     sprintf(texto, "%02d:%02d", minutos, segsTot);
    surf = TTF_RenderText_Solid(fuente, texto, color);
    tex  = SDL_CreateTextureFromSurface(ren, surf);
    dst.w = surf->w;
    dst.h = surf->h;

    //calculo de ventana

    int anchoVentana, altoVentana;
    SDL_GetRendererOutputSize(ren, &anchoVentana, &altoVentana);

    dst.x = anchoVentana - dst.w - 10; // 10px desde el borde derecho
    dst.y = 10;                         // 10px desde el borde superior
    SDL_FreeSurface(surf);
    SDL_RenderCopy(ren, tex, NULL, &dst);
    SDL_DestroyTexture(tex);

}

void animarMensaje(SDL_Renderer *ren, TTF_Font *fuente,char *texto,SDL_Color color)
{
    // 1) Medir el ancho y alto del mensaje en píxeles
    int anchoMensaje, altoMensaje;
    TTF_SizeText(fuente, texto, &anchoMensaje, &altoMensaje);

    // 2) Obtener el tamaño de la ventana
    int anchoVentana, altoVentana;
    SDL_GetRendererOutputSize(ren, &anchoVentana, &altoVentana);

    // 3) Calcular el rectángulo donde centrar el texto
    SDL_Rect cuadroTexto = {
        (anchoVentana - anchoMensaje) / 2,  // x
        (altoVentana  - altoMensaje ) / 2,  // y
        anchoMensaje,                       // w
        altoMensaje                         // h
    };

    // 4) Dibujar un fondo negro semitransparente
    SDL_SetRenderDrawBlendMode(ren, SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(ren, 0, 0, 0, 180);  // 180/255 de opacidad
    SDL_RenderFillRect(ren, NULL);

    // 5) Crear y dibujar la textura del texto
    SDL_Surface *superficie = TTF_RenderText_Blended(fuente, texto, color);
    SDL_Texture *textura    = SDL_CreateTextureFromSurface(ren, superficie);
    SDL_FreeSurface(superficie);

    SDL_RenderCopy(ren, textura, NULL, &cuadroTexto);
    SDL_DestroyTexture(textura);

    // 6) Mostrarlo todo y pausar 2 segundos
    SDL_RenderPresent(ren);
    SDL_Delay(3500);
}

void animarVictoria (SDL_Renderer *renderer, TTF_Font *fuente)
{
    SDL_Color verde= {0,200,0,255};
    animarMensaje (renderer, fuente,"GANASTE!!",verde);
}

void animarDerrota (SDL_Renderer *renderer, TTF_Font *fuente)
{
    SDL_Color rojo= {200,0,0,255};
    animarMensaje (renderer, fuente,"BOOM, GAME OVER!!",rojo);
}

void dibujarBandera (SDL_Renderer* renderizador,int fila,int col)
{
    // 1) Origen de la celda
    int x0 = col * CELL_SIZE;
    int y0 = PARTE_SUPERIOR + fila * CELL_SIZE;

    // 2) Coordenadas y longitud del mástil
    int poloX    = x0 + CELL_SIZE/2 - 1;    // línea centrada
    int poloY    = y0 + CELL_SIZE/4;        // 1/4 desde arriba
    int altoPolo = CELL_SIZE/2;             // mitad de la celda
    SDL_SetRenderDrawColor(renderizador, 139, 69, 19, 255);
    SDL_RenderDrawLine(renderizador,
                       poloX, poloY,
                       poloX, poloY + altoPolo);

    // 3) Paño de la bandera (ancho mayor que alto)
    int anchoPano = CELL_SIZE / 3;          // un tercio de la celda
    int altoPano  = CELL_SIZE / 6;          // un sexto de la celda
    int panoX     = poloX + 2;              // justo a la derecha del mástil
    int panoY     = poloY;                  // misma altura que la parte superior del mástil

    SDL_Rect rectPano = { panoX, panoY, anchoPano, altoPano };
    SDL_SetRenderDrawColor(renderizador, 200, 0, 0, 255);
    SDL_RenderFillRect(renderizador, &rectPano);
}


void dibujarBomba(SDL_Renderer *renderizador,int fila,int col)
{


    // Hacer la bomba más visible - llenar toda la celda de rojo primero
    int origenX = col * CELL_SIZE;
    int origenY = PARTE_SUPERIOR + fila * CELL_SIZE;

    SDL_Rect celdaCompleta = {origenX, origenY, CELL_SIZE, CELL_SIZE};
    SDL_SetRenderDrawColor(renderizador, 255, 0, 0, 255); // Rojo brillante
    SDL_RenderFillRect(renderizador, &celdaCompleta);

    // Luego dibujar la cruz negra encima para que se vea como bomba
    int centroX = origenX + CELL_SIZE/2;
    int centroY = origenY + CELL_SIZE/2;
    int brazo = CELL_SIZE / 4;

    SDL_SetRenderDrawColor(renderizador, 0, 0, 0, 255); // Negro para la cruz

    // Hacer las líneas más gruesas dibujando varias líneas paralelas
    for(int offset = -1; offset <= 1; offset++)
    {
        // vertical
        SDL_RenderDrawLine(renderizador,
                           centroX + offset, centroY - brazo,
                           centroX + offset, centroY + brazo);
        // horizontal
        SDL_RenderDrawLine(renderizador,
                           centroX - brazo, centroY + offset,
                           centroX + brazo, centroY + offset);
        // diagonal ↘
        SDL_RenderDrawLine(renderizador,
                           centroX - brazo + offset, centroY - brazo + offset,
                           centroX + brazo + offset, centroY + brazo + offset);
        // diagonal ↗
        SDL_RenderDrawLine(renderizador,
                           centroX - brazo + offset, centroY + brazo - offset,
                           centroX + brazo + offset, centroY - brazo - offset);
    }

    // Mecha (línea blanca arriba de la cruz) - más gruesa
    int largoMecha = CELL_SIZE / 6;
    SDL_SetRenderDrawColor(renderizador, 255, 255, 255, 255);
    for(int offset = -1; offset <= 1; offset++)
    {
        SDL_RenderDrawLine(renderizador,
                           centroX + offset, centroY - brazo,
                           centroX + offset, centroY - brazo - largoMecha);
    }

    // Chispa amarilla al final de la mecha - más grande
    SDL_SetRenderDrawColor(renderizador, 255, 255, 0, 255);
    SDL_Rect chispa = {
        centroX - 2,
        centroY - brazo - largoMecha - 3,
        4,
        4
    };
    SDL_RenderFillRect(renderizador, &chispa);
}


int pantallaInicio(SDL_Renderer *renderer, TTF_Font *fuente, char *nombre, int *bombas, int *dimension)
{
    SDL_StartTextInput();

    enum { FASE_NOMBRE, FASE_DIM, FASE_BOMBAS } fase = FASE_NOMBRE;
    char textoNombre   [MAX_NOMBRE] = "";
    char textoDimension[3]          = ""; // hasta 2 dígitos
    char textoBombas   [8]          = ""; // hasta "99%"

    bool errorDim  = false;
    bool errorBomb = false;
    bool fin       = false;

    SDL_Event ev;
    while (!fin) {
        // Procesar eventos
        while (SDL_PollEvent(&ev)) {
            // Si cierra ventana, salgo
            if (ev.type == SDL_QUIT || (ev.type == SDL_WINDOWEVENT && ev.window.event == SDL_WINDOWEVENT_CLOSE))
                {
                    SDL_StopTextInput();
                    return 0;
                }

            // Inserción de texto: solo aquí añadimos caracteres
            if (ev.type == SDL_TEXTINPUT) {
                const char *in = ev.text.text;
                if (fase == FASE_NOMBRE) {
                    if (strlen(textoNombre) < MAX_NOMBRE-1)
                        strcat(textoNombre, in);
                }
                else if (fase == FASE_DIM) {
                    // solo dígitos
                    if (isdigit((unsigned char)in[0]) &&
                        strlen(textoDimension) < 2)
                        strcat(textoDimension, in);
                }
                else { // FASE_BOMBAS
                    // dígitos o '%'
                    if ((isdigit((unsigned char)in[0]) || in[0]=='%') &&
                        strlen(textoBombas) < sizeof textoBombas-1)
                        strcat(textoBombas, in);
                }
            }

            // BACKSPACE y RETURN
            if (ev.type == SDL_KEYDOWN && ev.key.repeat == 0) {
                SDL_Keycode k = ev.key.keysym.sym;

                // BORRAR el último carácter
                if (k == SDLK_BACKSPACE) {
                    if (fase == FASE_NOMBRE && strlen(textoNombre))
                        textoNombre[strlen(textoNombre)-1] = '\0';
                    else if (fase == FASE_DIM && strlen(textoDimension))
                        textoDimension[strlen(textoDimension)-1] = '\0';
                    else if (fase == FASE_BOMBAS && strlen(textoBombas))
                        textoBombas[strlen(textoBombas)-1] = '\0';
                }
                // ENTER = validar y avanzar
                else if (k == SDLK_RETURN) {
                    if (fase == FASE_NOMBRE) {
                        if (strlen(textoNombre))
                            fase = FASE_DIM;
                    }
                    else if (fase == FASE_DIM) {
                        int d = atoi(textoDimension);
                        if (d >= 8 && d <= 32) {
                            *dimension = d;
                            fase        = FASE_BOMBAS;
                            errorDim    = false;
                        } else {
                            errorDim           = true;
                            textoDimension[0]  = '\0';
                        }
                    }
                    else { // FASE_BOMBAS
                        int totalC = (*dimension) * (*dimension);
                        int bval   = -1;
                        size_t L   = strlen(textoBombas);

                        if (L && textoBombas[L-1] == '%') {
                            textoBombas[L-1] = '\0';
                            int pct = atoi(textoBombas);
                            if (pct > 0) bval = totalC / pct;
                        } else {
                            int b = atoi(textoBombas);
                            if (b >= 1 && b < totalC) bval = b;
                        }

                        if (bval >= 1 && bval < totalC) {
                            *bombas = bval;
                            fin     = true;
                        } else {
                            errorBomb = true;
                            textoBombas[0] = '\0';
                        }
                    }
                }
            }
        }

        // Renderizar todo
        SDL_Window *win = SDL_RenderGetWindow(renderer);
        int W,H; SDL_GetWindowSize(win,&W,&H);

        SDL_SetRenderDrawColor(renderer,230,230,230,255);
        SDL_RenderClear(renderer);

        SDL_Color negro={0,0,0,255}, rojo={200,0,0,255};

        // Pregunta según fase
            char *preg;

            if (fase == FASE_NOMBRE)
                {
                    preg = "Ingrese su nombre:";
                }
            else if (fase == FASE_DIM)
                {
                    preg = "Ingrese dimension (8-32):";
                }
                else
                    {
                        preg = "Ingrese cantidad minas (n o n%):";
                    }
        SDL_Surface *sf = TTF_RenderText_Blended(fuente,preg,negro);
        SDL_Texture *tx = SDL_CreateTextureFromSurface(renderer,sf);
        SDL_Rect rq={40,H/2-100,sf->w,sf->h};
        SDL_RenderCopy(renderer,tx,NULL,&rq);
        SDL_FreeSurface(sf); SDL_DestroyTexture(tx);

        // Caja de input
        SDL_Rect box={40,H/2-20,W-80,40};
        SDL_SetRenderDrawColor(renderer,255,255,255,255);
        SDL_RenderFillRect(renderer,&box);
        SDL_SetRenderDrawColor(renderer,0,0,0,255);
        SDL_RenderDrawRect(renderer,&box);

        // Texto ingresado
        char *txt;
            if (fase == FASE_NOMBRE)
                {
                    txt = textoNombre;
                }
                else if (fase == FASE_DIM)
                    {
                        txt = textoDimension;
                    }
                else
                    {
                        txt = textoBombas;
                    }
        if (*txt)
            {
                sf = TTF_RenderText_Blended(fuente,txt,negro);
                tx = SDL_CreateTextureFromSurface(renderer,sf);
                SDL_Rect rt={box.x+10, box.y+6, sf->w, sf->h};
                SDL_RenderCopy(renderer,tx,NULL,&rt);
                SDL_FreeSurface(sf); SDL_DestroyTexture(tx);
            }

        static Uint32 tiempoAnterior = 0;
        Uint32 tiempoActual = SDL_GetTicks();

        if (tiempoActual - tiempoAnterior > 500)
            tiempoAnterior = tiempoActual;

        // sólo durante los primeros 250ms del ciclo
        if (tiempoActual - tiempoAnterior < 250) {
            // posición X al final del texto
            int anchoTexto = 0, altoTexto = 0;
            if (*txt) {
                TTF_SizeText(fuente, txt, &anchoTexto, &altoTexto);
            }

            // el cursor ocupará casi toda la caja (box.h) y tendrá 2px de ancho
            int xCursor = box.x + 10 + anchoTexto;
            int yStart = box.y + 4;            // 4px de margen arriba
            int yEnd   = box.y + box.h - 4;    // 4px de margen abajo

            SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
            // dibuja dos líneas paralelas para hacerlo más grueso
            SDL_RenderDrawLine(renderer,
                               xCursor,     yStart,
                               xCursor,     yEnd);
            SDL_RenderDrawLine(renderer,
                               xCursor + 1, yStart,
                               xCursor + 1, yEnd);
        }
        // Errores
        if (errorDim && fase==FASE_DIM) {
            sf = TTF_RenderText_Blended(fuente,"Dimension debe ser 8-32",rojo);
            tx = SDL_CreateTextureFromSurface(renderer,sf);
            SDL_Rect re={box.x, box.y+box.h+10, sf->w, sf->h};
            SDL_RenderCopy(renderer,tx,NULL,&re);
            SDL_FreeSurface(sf); SDL_DestroyTexture(tx);
        }
        if (errorBomb && fase==FASE_BOMBAS) {
            sf = TTF_RenderText_Blended(fuente,"Cantidad invalida",rojo);
            tx = SDL_CreateTextureFromSurface(renderer,sf);
            SDL_Rect re={box.x, box.y+box.h+10, sf->w, sf->h};
            SDL_RenderCopy(renderer,tx,NULL,&re);
            SDL_FreeSurface(sf); SDL_DestroyTexture(tx);
        }

        // Instrucción final
        sf = TTF_RenderText_Blended(fuente,"ENTER para continuar",negro);
        tx = SDL_CreateTextureFromSurface(renderer,sf);
        SDL_Rect ri={40,H-60,sf->w,sf->h};
        SDL_RenderCopy(renderer,tx,NULL,&ri);
        SDL_FreeSurface(sf); SDL_DestroyTexture(tx);

        SDL_RenderPresent(renderer);
        SDL_Delay(16);
    }

    // Copiar nombre al buffer externo
    strcpy(nombre, textoNombre);
    SDL_StopTextInput();
    return 1;
}

TTF_Font* inicializarTTF(const char* rutaFuente, int tamanio)
{
    TTF_Font* fuente = TTF_OpenFont(rutaFuente, tamanio);
    if (!fuente) {
        printf("Error al abrir la fuente: %s\n", TTF_GetError());
        return NULL;
    }
    return fuente;
}


void cerrarTTF(TTF_Font* fuente)
{
    TTF_CloseFont(fuente);
    TTF_Quit();
}


void mostrarNumero(SDL_Renderer* ren, TTF_Font* fuente, int numero, int fila, int col)
{

     if (numero == 0) {
        return; // No dibujar nada para celdas con 0 minas adyacentes
    }
    char texto[2];
    sprintf(texto, "%d", numero);

    SDL_Color color = {0,0,0};
    SDL_Surface* surf = TTF_RenderText_Solid(fuente, texto, color);
    if (!surf) {
        return; // Validar que la superficie se creó correctamente
    }
    SDL_Texture* tex  = SDL_CreateTextureFromSurface(ren, surf);
    if (!tex) {
        SDL_FreeSurface(surf);
        return; // Validar que la textura se creó correctamente
    }
    int texW, texH;
    SDL_QueryTexture(tex, NULL, NULL, &texW, &texH);


    SDL_Rect dst = {
      col * CELL_SIZE + (CELL_SIZE - texW)/2,
      PARTE_SUPERIOR + fila * CELL_SIZE + (CELL_SIZE - texH)/2,
      texW, texH
    };

    SDL_RenderCopy(ren, tex, NULL, &dst);
    SDL_DestroyTexture(tex);
    SDL_FreeSurface(surf);
}
