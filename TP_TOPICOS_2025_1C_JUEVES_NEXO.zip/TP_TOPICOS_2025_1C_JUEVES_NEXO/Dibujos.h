#ifndef DIBUJOS_H_INCLUDED
#define DIBUJOS_H_INCLUDED
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>
#define NombreArch "buscaminas.conf"
#define FORMATO "CANTIDAD DE MINAS = %[^|]| DIMENSION DEL�TABLERO�=�%d"
#define TAM 8
#define FILAS 8
#define WINDOW_SIZE (TAM * CELL_SIZE)
#define MAX_NOMBRE 20
#define TAM_PIXEL 10
#define PIXELES_X_LADO 8
#define TAM_GRILLA 10
#define PX_PADDING 4
#define CELL_SIZE 40
#define PARTE_SUPERIOR  (CELL_SIZE+10)
#define CHEAT_DURATION_MS 1000

void dibujar(SDL_Window *ventana, SDL_Renderer *renderer, const int dibujo[][PIXELES_X_LADO], int oX, int oY);
void borrarPantalla(SDL_Window *ventana, SDL_Renderer *renderer);
void parteSuperior(SDL_Renderer*, TTF_Font*,int,int,Uint32); //uINT32 ES UN ENTERO SIN SIGNO DE 32 BITS
void animarMensaje(SDL_Renderer*, TTF_Font*,char*,SDL_Color);
void animarVictoria (SDL_Renderer*, TTF_Font*);
void animarDerrota (SDL_Renderer*, TTF_Font*);
void dibujarBandera (SDL_Renderer*,int,int);
void dibujarBomba(SDL_Renderer *,int,int);
void inicializarSDL(SDL_Window**, SDL_Renderer**, int);
void limpiarSDL(SDL_Window*, SDL_Renderer*);
int pantallaInicio(SDL_Renderer*, TTF_Font*, char*, int*, int*);
TTF_Font* inicializarTTF(const char*, int);
void cerrarTTF(TTF_Font*);
void mostrarNumero(SDL_Renderer*, TTF_Font*, int, int , int );


#endif // DIBUJOS_H_INCLUDED
