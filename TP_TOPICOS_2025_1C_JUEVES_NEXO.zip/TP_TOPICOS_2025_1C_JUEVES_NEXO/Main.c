#include "juego.h"
#include "dibujos.h"

/*
Apellido(s), nombre(s): Bruno, Santino
DNI: 44392059
Entrega: Si

Apellido(s), nombre(s): Zarlenga, Bianca Camila
DNI: 43993165
Entrega: Si

Apellido(s), nombre(s): Cejas Nu�ez, Nahuel Facundo
DNI: N/A
Entrega:�NO
*/


int main(int argc, char *argv[])
{
    tDatosMatriz **matriz;
    SDL_Renderer* ren;
    TTF_Font* fuente;

    // Inicializar SDL y TTF
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        printf("Error al inicializar SDL: %s\n", SDL_GetError());
        return -1;
    }

    if (TTF_Init() == -1) {
        printf("Error al inicializar TTF: %s\n", TTF_GetError());
        SDL_Quit();
        return -2;
    }
    tConfig conf;
    char nombreJugador[MAX_NOMBRE];
    int dimensionJuego = 0;
    int bombasJuego = 0;

    // Crear ventana inicial (se redimensionar� despu�s)
    SDL_Window* win = SDL_CreateWindow("Buscaminas",
                                       SDL_WINDOWPOS_CENTERED,
                                       SDL_WINDOWPOS_CENTERED,
                                       500, 400,  // Tama�o inicial para pantalla de inicio
                                       0);

    if (!win) {
        printf("Error al crear la ventana: %s\n", SDL_GetError());
        TTF_Quit();
        SDL_Quit();
        return -1;
    }

    ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED);
    if (!ren) {
        printf("Error al crear el renderer: %s\n", SDL_GetError());
        SDL_DestroyWindow(win);
        TTF_Quit();
        SDL_Quit();
        return -1;
    }

    // Intentar cargar diferentes fuentes
    fuente = TTF_OpenFont("Fnt/ARIAL.ttf", 24);
    if (!fuente) {
        // Intentar con otras fuentes comunes
        fuente = TTF_OpenFont("DejaVuSans.ttf", 24);
        if (!fuente) {
            fuente = TTF_OpenFont("Liberation-Sans.ttf", 24);
            if (!fuente) {
                // Crear una fuente por defecto si no encuentra ninguna
                printf("Advertencia: No se pudo cargar ninguna fuente: %s\n", TTF_GetError());
                printf("El juego continuar� pero puede tener problemas de visualizaci�n\n");
                // Puedes continuar sin fuente o terminar aqu�
                SDL_DestroyRenderer(ren);
                SDL_DestroyWindow(win);
                TTF_Quit();
                SDL_Quit();
                return -1;
            }
        }
    }

    // Mostrar pantalla de inicio
    if (!pantallaInicio(ren, fuente, nombreJugador, &bombasJuego, &dimensionJuego))
    {
        // El usuario cerr� la ventana
        TTF_CloseFont(fuente);
        SDL_DestroyRenderer(ren);
        SDL_DestroyWindow(win);
        TTF_Quit();
        SDL_Quit();
        return -1;
    }

    printf("\nJugador: %s, Dimension: %d, Bombas: %d\n", nombreJugador, dimensionJuego, bombasJuego);
    printf("\nActivar cheat con CTRL + S (solo una vez por partida)\n");
    printf("\nValido despues de realizar el primer click\n");
    registrarInicio(nombreJugador,dimensionJuego,bombasJuego);

    // Actualizar configuraci�n con valores del usuario
    conf.dimension = dimensionJuego;
    conf.cantMinas = bombasJuego;
    if (!guardarConfig("Buscaminas.CONF",conf.dimension,conf.cantMinas))
    {
        printf("\n error al guardar las config");
    }

    // Redimensionar ventana para el juego
    SDL_SetWindowSize(win,
                      conf.dimension * CELL_SIZE,
                      PARTE_SUPERIOR + conf.dimension * CELL_SIZE);    SDL_SetWindowPosition(win, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED);


    // Crear matriz del juego
    matriz = crearMatriz(conf.dimension);
    if (!matriz)
    {
        printf("\nError al generar la matriz");
        limpiarSDL(win, ren);
        cerrarTTF(fuente);
        return -1;
    }

    // Inicializar y jugar
    inicializarMatrizEnCero(matriz, conf.dimension);

    // Limpiar la pantalla antes de empezar el juego
    SDL_SetRenderDrawColor(ren, 200, 200, 200, 255);
    SDL_RenderClear(ren);
    SDL_RenderPresent(ren);

    jugar(matriz, conf.dimension, conf.cantMinas, fuente);

    // Limpiar recursos
    destruirMatriz(matriz, conf.dimension);
    limpiarSDL(win, ren);
    cerrarTTF(fuente);
    return 0;
}
